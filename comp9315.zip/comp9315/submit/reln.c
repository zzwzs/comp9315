// reln.c ... functions on Relations
// part of Multi-attribute Linear-hashed Files
// Last modified by John Shepherd, July 2019

#include "defs.h"
#include "reln.h"
#include "page.h"
#include "tuple.h"
#include "chvec.h"
#include "bits.h"
#include "hash.h"

#define HEADERSIZE (3*sizeof(Count)+sizeof(Offset))

struct RelnRep {
	Count  nattrs; // number of attributes
	Count  depth;  // depth of main data file
	Offset sp;     // split pointer
    Count  npages; // number of main data pages
    Count  ntups;  // total number of tuples
	ChVec  cv;     // choice vector
	char   mode;   // open for read/write
	FILE  *info;   // handle on info file
	FILE  *data;   // handle on data file
	FILE  *ovflow; // handle on ovflow file
};

// create a new relation (three files)

Status newRelation(char *name, Count nattrs, Count npages, Count d, char *cv)
{
    char fname[MAXFILENAME];
	Reln r = malloc(sizeof(struct RelnRep));
	r->nattrs = nattrs; r->depth = d; r->sp = 0;
	r->npages = npages; r->ntups = 0; r->mode = 'w';
	assert(r != NULL);
	if (parseChVec(r, cv, r->cv) != OK) return ~OK;
	sprintf(fname,"%s.info",name);
	r->info = fopen(fname,"w");
	assert(r->info != NULL);
	sprintf(fname,"%s.data",name);
	r->data = fopen(fname,"w");
	assert(r->data != NULL);
	sprintf(fname,"%s.ovflow",name);
	r->ovflow = fopen(fname,"w");
	assert(r->ovflow != NULL);
	int i;
	for (i = 0; i < npages; i++) addPage(r->data);
	closeRelation(r);
	return 0;
}

// check whether a relation already exists

Bool existsRelation(char *name)
{
	char fname[MAXFILENAME];
	sprintf(fname,"%s.info",name);
	FILE *f = fopen(fname,"r");
	if (f == NULL)
		return FALSE;
	else {
		fclose(f);
		return TRUE;
	}
}

// set up a relation descriptor from relation name
// open files, reads information from rel.info

Reln openRelation(char *name, char *mode)
{
	Reln r;
	r = malloc(sizeof(struct RelnRep));
	assert(r != NULL);
	char fname[MAXFILENAME];
	sprintf(fname,"%s.info",name);
	r->info = fopen(fname,mode);
	assert(r->info != NULL);
	sprintf(fname,"%s.data",name);
	r->data = fopen(fname,mode);
	assert(r->data != NULL);
	sprintf(fname,"%s.ovflow",name);
	r->ovflow = fopen(fname,mode);
	assert(r->ovflow != NULL);
	// Naughty: assumes Count and Offset are the same size
	int n = fread(r, sizeof(Count), 5, r->info);
	assert(n == 5);
	n = fread(r->cv, sizeof(ChVecItem), MAXCHVEC, r->info);
	assert(n == MAXCHVEC);
	r->mode = (mode[0] == 'w' || mode[1] =='+') ? 'w' : 'r';
	return r;
}

// release files and descriptor for an open relation
// copy latest information to .info file

void closeRelation(Reln r)
{
	// make sure updated global data is put in info
	// Naughty: assumes Count and Offset are the same size
	if (r->mode == 'w') {
		fseek(r->info, 0, SEEK_SET);
		// write out core relation info (#attr,#pages,d,sp)
		int n = fwrite(r, sizeof(Count), 5, r->info);
		assert(n == 5);
		// write out choice vector
		n = fwrite(r->cv, sizeof(ChVecItem), MAXCHVEC, r->info);
		assert(n == MAXCHVEC);
	}
	fclose(r->info);
	fclose(r->data);
	fclose(r->ovflow);
	free(r);
}

// insert a new tuple into a relation
// returns index of bucket where inserted
// - index always refers to a primary data page
// - the actual insertion page may be either a data page or an overflow page
// returns NO_PAGE if insert fails completely
// TODO: include splitting and file expansion

PageID makePage_getID(Reln r, Tuple t, PageID pid);

void split(Reln r) {
	// add a new page for split
	addPage(r->data);
	r->npages++;
	//store all the tuples in original page
	Tuple *tup_store = malloc(1024 * sizeof(Tuple));
	//grab info for this page
	PageID page_id = r->sp;
	FILE * data = r->data;
	Offset cur_tuple = 0;
	Count num_tuples = 0;
	int index = 0;
	while (page_id != NO_PAGE){
		Page p = getPage(data, page_id);
		// if there are no more tuples then break the loop
		if(pageNTuples(p) == 0){
			break;
		}

		char line[MAXTUPLEN];
		Offset base = PAGESIZE * page_id + 2 * sizeof(Offset) + sizeof(Count);
		fseek(data, base+cur_tuple, SEEK_SET);
		fgets(line, MAXTUPLEN-1,data);
		Tuple next_tuple = copyString(line);
		Bits hash;
		Bits pg_id;
		hash = tupleHash(r, next_tuple);
		pg_id = getLower(hash, r->depth + 1);
		//if the pageid is same as ori page then this tuple should stay in ori page
		if (pg_id == page_id){
			tup_store[index++] = copyString(next_tuple);	//copyString from util.h and util.c files
		} else {
			PageID new_page = makePage_getID(r, next_tuple, pg_id);
			if (new_page == NO_PAGE)
				printf("Sth wrong! No page found\n");
		}
		//move to next tuple & tuple num + 1
		cur_tuple += strlen(next_tuple)+1;
		num_tuples++;
		//if the num of tuples is more than page size then create a new page
		if (num_tuples >= pageNTuples(p)){
			Page new = newPage();
			putPage(data, page_id, new);
			page_id = pageOvflow(p);
			num_tuples = 0;
			cur_tuple = 0;
			data = r->ovflow;
		}
		free(next_tuple);
		free(p);
	}

    int i;
	for (i = 0; i < index; i++){
		makePage_getID(r, tup_store[i], r->sp);
	}

	free(tup_store);
	if (getLower(r->sp + 1, r->depth) == 0){	// if sp enough then sp +1 otherwise depth + 1 and sp -> 0
		//r->sp++;
		r->depth++;
		r->sp = 0;
	} else{
		r->sp++;
	}
}

PageID addToRelation(Reln r, Tuple t)
{
	// at first let us confirm whether we need split or not
	int overf = (r->ntups + 1) % (1024/(10*r->nattrs));
	if (overf == 0) split(r);
	
	Bits h, p;
	// char buf[MAXBITS+1];
	h = tupleHash(r,t);
	if (r->depth == 0)
		p = 1;
	else {
		p = getLower(h, r->depth);
		if (p < r->sp) p = getLower(h, r->depth+1);
	}
	// bitsString(h,buf); printf("hash = %s\n",buf);
	// bitsString(p,buf); printf("page = %s\n",buf);
	Page pg = getPage(r->data,p);
	if (addToPage(pg,t) == OK) {
		putPage(r->data,p,pg);
		r->ntups++;
		return p;
	}
	// primary data page full
	if (pageOvflow(pg) == NO_PAGE) {
		// add first overflow page in chain
		PageID newp = addPage(r->ovflow);
		pageSetOvflow(pg,newp);
		putPage(r->data,p,pg);
		Page newpg = getPage(r->ovflow,newp);
		// can't add to a new page; we have a problem
		if (addToPage(newpg,t) != OK) return NO_PAGE;
		putPage(r->ovflow,newp,newpg);
		r->ntups++;
		return p;
	}
	else {
		// scan overflow chain until we find space
		// worst case: add new ovflow page at end of chain
		Page ovpg, prevpg = NULL;
		PageID ovp, prevp = NO_PAGE;
		ovp = pageOvflow(pg);
		while (ovp != NO_PAGE) {
			ovpg = getPage(r->ovflow, ovp);
			if (addToPage(ovpg,t) != OK) {
				prevp = ovp; prevpg = ovpg;
				ovp = pageOvflow(ovpg);
			}
			else {
				if (prevpg != NULL) free(prevpg);
				putPage(r->ovflow,ovp,ovpg);
				r->ntups++;
				return p;
			}
		}
		// all overflow pages are full; add another to chain
		// at this point, there *must* be a prevpg
		assert(prevpg != NULL);
		// make new ovflow page
		PageID newp = addPage(r->ovflow);
		// insert tuple into new page
		Page newpg = getPage(r->ovflow,newp);
        if (addToPage(newpg,t) != OK) return NO_PAGE;
        putPage(r->ovflow,newp,newpg);
		// link to existing overflow chain
		pageSetOvflow(prevpg,newp);
		putPage(r->ovflow,prevp,prevpg);
        r->ntups++;
		return p;
	}
	return NO_PAGE;
}

PageID makePage_getID(Reln r, Tuple next_tuple, PageID pg_id)
{
	Page pg = getPage(r->data,pg_id);

	if (addToPage(pg, next_tuple) == 0) {	//return 0 if room is enough
		putPage(r->data, pg_id, pg);
		return pg_id;
	}
	// page full
	if (pageOvflow(pg) == NO_PAGE) {
		// add first overflow page
		PageID first_p = addPage(r->ovflow);
		pageSetOvflow(pg, first_p);
		putPage(r->data, pg_id, pg);
		Page first_page = getPage(r->ovflow, first_p);
		putPage(r->ovflow, first_p, first_page);
		return pg_id;
	} else {
		// go through overflow till we find room
		// if there is no room then create a new page
		Page ovflowpg = NULL;
    Page prevpg = NULL;
    PageID ovflowpgID = NO_PAGE;
    PageID prevpgID = NO_PAGE;
    ovflowpgID = pageOvflow(pg);
    while (ovflowpgID != NO_PAGE){
      ovflowpg = getPage(r->ovflow, ovflowpgID);
      if (addToPage(ovflowpg, next_tuple) != 0) {
        prevpgID = ovflowpgID;
        prevpg = ovflowpg;
        ovflowpgID = pageOvflow(ovflowpg);
      } else {
        if (prevpg != NULL)	free(prevpg);
        putPage(r->ovflow, ovflowpgID, ovflowpg);
        return pg_id;
      }
    }
		// all overflow pages are full; add another to chain
		// at this point, there *must* be a prevpg
		assert(prevpg != NULL);
		// make new ovflow page
		PageID newp = addPage(r->ovflow);
		// insert tuple into new page
		Page newpg = getPage(r->ovflow,newp);
        if (addToPage(newpg,next_tuple) != OK) return NO_PAGE;
        putPage(r->ovflow,newp,newpg);
		// link to existing overflow chain
		pageSetOvflow(prevpg,newp);
		putPage(r->ovflow,prevpgID,prevpg);
        r->ntups++;
		return pg_id;
	}
}

// external interfaces for Reln data

FILE *dataFile(Reln r) { return r->data; }
FILE *ovflowFile(Reln r) { return r->ovflow; }
Count nattrs(Reln r) { return r->nattrs; }
Count npages(Reln r) { return r->npages; }
Count ntuples(Reln r) { return r->ntups; }
Count depth(Reln r)  { return r->depth; }
Count splitp(Reln r) { return r->sp; }
ChVecItem *chvec(Reln r)  { return r->cv; }


// displays info about open Reln

void relationStats(Reln r)
{
	printf("Global Info:\n");
	printf("#attrs:%d  #pages:%d  #tuples:%d  d:%d  sp:%d\n",
	       r->nattrs, r->npages, r->ntups, r->depth, r->sp);
	printf("Choice vector\n");
	printChVec(r->cv);
	printf("Bucket Info:\n");
	printf("%-4s %s\n","#","Info on pages in bucket");
	printf("%-4s %s\n","","(pageID,#tuples,freebytes,ovflow)");
	for (Offset pid = 0; pid < r->npages; pid++) {
		printf("[%2d]  ",pid);
		Page p = getPage(r->data, pid);
		Count ntups = pageNTuples(p);
		Count space = pageFreeSpace(p);
		Offset ovid = pageOvflow(p);
		printf("(d%d,%d,%d,%d)",pid,ntups,space,ovid);
		free(p);
		while (ovid != NO_PAGE) {
			Offset curid = ovid;
			p = getPage(r->ovflow, ovid);
			ntups = pageNTuples(p);
			space = pageFreeSpace(p);
			ovid = pageOvflow(p);
			printf(" -> (ov%d,%d,%d,%d)",curid,ntups,space,ovid);
			free(p);
		}
		putchar('\n');
	}
}

