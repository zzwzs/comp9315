// query.c ... query scan functions
// part of Multi-attribute Linear-hashed Files
// Manage creating and using Query objects
// Last modified by John Shepherd, July 2019

#include "defs.h"
#include "query.h"
#include "reln.h"
#include "tuple.h"
#include "hash.h"
#include "page.h"

// A suggestion ... you can change however you like

struct QueryRep {
	Reln    rel;       // need to remember Relation info
	Bits    known;     // the hash value from MAH
	Bits    unknown;   // the unknown bits from MAH
	PageID  curpage;   // current page in scan
	PageID	bucket;		 // current bucket in scan
	int     is_ovflow; // are we in the overflow pages?
	Offset  curtup;    // offset of current tuple within page
	//TODO
	Tuple  query;
	Count  num_Tuples;	//the num of tuples
};

// take a query string (e.g. "1234,?,abc,?")
// set up a QueryRep object for the scan

Query startQuery(Reln r, char *q)
{
	Query new = malloc(sizeof(struct QueryRep));
	assert(new != NULL);
	// TODO
	// Partial algorithm:
	// form known bits from known attributes
	// form unknown bits from '?' attributes
	// compute PageID of first page
	//   using known bits and first "unknown" value
	// set all values in QueryRep object
	Count nvals = nattrs(r);												//nattrs func from reln.h and reln.c files
	char **vals = malloc(nvals * sizeof(char *));
	tupleVals(q, vals);
	ChVecItem *cv = chvec(r);
	new->known = 0;
	Bits hashAtt[nvals];
	//now try set all unknown bits to 0, set all known to hash_any
	int i;
	for(i = 0; i < nvals; i++){
		if (vals[i][0] == '?'){
			hashAtt[i] = 0;
		} else {
			hashAtt[i] = hash_any((unsigned char *)vals[i], strlen(vals[i]));
		}
	}
	int j;
	for (j = 0; j < MAXCHVEC; j++){
		Byte a = (cv+j) -> att;
		Byte b = (cv+j) -> bit;
		if (bitIsSet(hashAtt[a], b)){
			new->known = setBit(new->known, j);
		}
		// if the bits was set to 0 from unknown
		if (hashAtt[a] == 0x0) {
			new->unknown = setBit(new->unknown, j);
		}
	}
	Bits low;
	if (depth(r) == 0){
		low = 1;
	} else {
		low = getLower(new->known, depth(r));
		if (low < splitp(r)){
			low = getLower(new->known, depth(r) + 1);
		}

	}
	new->rel = r;
	new->curpage = low;
	new->bucket = low;
	new->is_ovflow = FALSE;
	new->curtup = 0u;			//unsigned int
	new->query = q;
	new->num_Tuples = 0u; //unsigned int
	freeVals(vals, nvals);
	return new;
}

// get next tuple during a scan
Bool validQueryBucket(PageID bucketID, Bits known, Bits unknown, Reln r);
Tuple getNextTuple(Query q)
{
	// TODO
	// Partial algorithm:
	// if (more tuples in current page)
	//    get next matching tuple from current page
	// else if (current page has overflow)
	//    move to overflow page
	//    grab first matching tuple from page
	// else
	//    move to "next" bucket
	//    grab first matching tuple from data page
	// endif
	// if (current page has no matching tuples)
	//    go to next page (try again)
	// endif
	Page single;
Loop:
	if (q->is_ovflow == 0){
		single = getPage(dataFile(q->rel), q->curpage);	// dataFile func from reln.h
	} else{
		single = getPage(ovflowFile(q->rel), q->curpage);	// ovflowFile func from reln.h
	}
	//if the length of q is shoter than page size then keep test match if match then return
	while (q->num_Tuples < pageNTuples(single)){	//pageNTuples func from page.h
		Tuple cur_tuple = q->query;
		Tuple off_next = (char *)(pageData(single) + q->curtup);	//pageData func from page.h
		if (tupleMatch(q->rel, cur_tuple, off_next)){	//tupleMatch from tuple.h and tuple.c files
			q->num_Tuples += 1;										//num of tuple + 1
			q->curtup += tupLength(off_next) + 1;	//move to next tuple
			return off_next;
		}
		//if not match just move to next tuple but not return
		q->num_Tuples += 1;											
		q->curtup += tupLength(off_next) + 1;
	}
	// if the page is full then go next page
	while (pageOvflow(single) != NO_PAGE){	//pageOvflow func from page.h
		//create new q node
		q->is_ovflow = TRUE;
		q->num_Tuples = 0u;		//unsigned int
		q->curpage = pageOvflow(single);
		q->curtup = 0u;				//unsigned int

		single = getPage(ovflowFile(q->rel), q->curpage);
		//if the length of q is shoter than page size then keep test match if match then return
		while (q->num_Tuples < pageNTuples(single)){	//same as above
			Tuple cur_tuple = q->query;
			Tuple off_next = (char *)(pageData(single) + q->curtup);
			if (tupleMatch(q->rel, cur_tuple, off_next)){
				q->num_Tuples += 1;
				q->curtup += tupLength(off_next) + 1;
				return off_next;
			}
			q->num_Tuples += 1;
			q->curtup += tupLength(off_next) + 1;
		}
	}

	//if nothing return. then we need to go to next bucket.
	q->is_ovflow = FALSE;
	q->num_Tuples = 0u;
	q->curpage = pageOvflow(single);
	q->curtup = 0u;
	// change id to next bucket
	PageID next_id = q->bucket + 1;
	while (TRUE){
		// the num of npages(q->rel) is bucket.
		if (next_id >= npages(q->rel)){	//if next id greater than max num of pages
			return NULL;
		}
		Bits mask = next_id & (~q->unknown);
		unsigned int sp = 0u;
		PageID pg_id = getLower(next_id, depth(q->rel));
		if (pg_id < splitp(q->rel)){
			sp = 1u;
		}
		//if pg is enough then + 1 otherwise dont need
		//this step is fro query bucket validation
		if (getLower(q->known, depth(q->rel) + sp) == mask){
			// if this bucket valid then grab info for q and then run while loop like before
			// to find pos for next tuple
			q->bucket = next_id;
			q->curpage = next_id;
			goto Loop;
		} else {
			// if this id already used or sth wrong, then go next pos till we move to a valid bucket
			next_id += 1;
		}
	}
	free(single);
	return NULL;
}
// clean up a QueryRep object and associated data

void closeQuery(Query q)
{
	// TODO
	free(q);
}

