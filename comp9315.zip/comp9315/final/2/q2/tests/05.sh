./q2 data/Data4
