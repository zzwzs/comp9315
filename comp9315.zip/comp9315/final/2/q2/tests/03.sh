./q2 data/Data2
