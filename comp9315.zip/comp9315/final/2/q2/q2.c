// COMP9315 22T1 Final Exam Q1
// Find longest tuple in a no-frills file

#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include "no-frills.h"

int main(int argc, char **argv)
{
	if (argc < 2) {
		printf("Usage: %s DataFile\n", argv[0]);
		exit(1);
	}
	FILE *fd;
	fd = fopen(argv[1],"r");
	if (fd == NULL){
		printf("Can't open file %s\n", argv[1]);
		exit(1);
	}
	char longest[MAXTUPLEN];

	// Add variables and code here to find
	// the longest tuple in the data file
	char line[3000];
	int length = 0;
	int switch1 = 0;
	if (fgets(line,16,fd) == NULL){
	    printf("%s\n","<none>");
	    return 0;
	}
	fclose(fd);
	fd = fopen(argv[1],"r");
	while(fgets(line,2999,fd)){
		char *c; int nf = 0;
		char* temp;
		//char* temp = strcpy(t);
		for(c = line; *c != '\0'; c++){
		    if (*c == '\0'){
		        switch1 = 1;
		        if (strlen(temp) > length){
			        length = strlen(temp);
			        strcpy(longest,temp);
		        }
		    //temp = strcpy(t);
		    nf = 0;
		    }
			temp = strcat(temp,c);
			nf++;
		}
		
	}
    if (switch1 == 0){
        printf("%s\n","<none>");
        return 0;
    }
	printf("%s\n",longest);
	return 0;
}
