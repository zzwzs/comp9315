// COMP9315 22T1 Final Exam Q1
// Count tuples in a no-frills file

#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include "no-frills.h"

int main(int argc, char **argv)
{
	if (argc < 2) {
		printf("Usage: %s DataFile\n", argv[0]);
		exit(1);
	}
	FILE *fd;
	fd = fopen(argv[1],"r");
	if (fd == NULL) {
		printf("Can't open file %s\n", argv[1]);
		exit(1);
	}
	
	int ntuples = 0;
	//int flag = 0;
	char line[3000];
	if (fgets(line,16,fd) == NULL){
	    ntuples = -1;
	    printf("%d\n",ntuples);
	    return 0;
	}
	line[strlen(line)-1] = '\1';
    char *c;
    c = line;
    ntuples += *c;
    for (c = line; *c!='\1'; c++){
        
        if (*c == '\0'){
            c--;
            ntuples += atoi(c);
            c++;
        }
    }
    
    //while(fgets(line,16,fd) != NULL){
	//    line[strlen(line)-1] = '\0';
	//    char *c; 
	//    c = line;
    //    ntuples += *c;
    //}
	printf("%d\n",ntuples);
	return 0;
}
