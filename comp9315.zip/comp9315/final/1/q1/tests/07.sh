./q1 data/Data6
