./q1 data/Data5
