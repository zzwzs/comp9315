./q1 data/Data2
